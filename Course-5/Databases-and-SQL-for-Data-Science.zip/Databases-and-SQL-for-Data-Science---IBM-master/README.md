# Databases-and-SQL-for-Data-Science---IBM
A set of notebooks from the IBM professional certificate that cover how to do exploratory analyses and queries using SQL. These notebooks cover how to run SQL in the DB2 database from IBM. They also cover how to use Python to run SQL queries by establishing a connection to the server. 
